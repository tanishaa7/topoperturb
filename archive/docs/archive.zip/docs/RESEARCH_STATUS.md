# TopoPerturb research status

Audit: 31 October 2026. **The project supports a useful exploratory methods poster,
but does not yet establish genuine topological changes in real perturbations.**
Original scientific code and outputs are preserved. Detailed checks and sources
are in [AUDIT_EVIDENCE.md](AUDIT_EVIDENCE.md).

## 1. What exists

- Two unexecuted [notebooks](../experiments/) for dataset auditing and PCA/Mapper;
  saved counts cover 162,751 K562 and 162,733 RPE1 cells, including excluded cells.
- [Pilot](../topoperturb_pilot_outputs/), [initial PH](../topoperturb_ph_outputs/),
  [Phase 1](../topoperturb_phase1_outputs/) and [Phase 2](../topoperturb_phase2_outputs/)
  tables/figures: eight K562 targets, four shared RPE1 targets, sampling/PCA
  sensitivity, scale normalization, conventional baselines and Gaussian surrogates.
  PH/Phase 1–2 generating scripts are missing.
- A runnable [benchmark](../topoperturb_benchmark/): 12 synthetic conditions × 40
  replicates and 15 real groups × 15 draws, each comparing 150 versus 150 cells
  in 30 dimensions. Ten tests include energy, covariance difference, Euclidean
  H0/H1, corrected resistance, diffusion H1 and Gaussian-surrogate comparisons.
  Saved PCA clouds contain 13,534 K562 and 13,899 RPE1 cells; raw expression
  matrices, PCA loadings and cell/guide/batch identifiers are absent.

## 2. What is verified

- Saved PCA label counts agree with the inventories; the K562 control covariance
  reproduces the synthetic metadata (participation ratio 16.64, top-two variance
  share 25.93%). Re-executing notebook selection on saved counts recovers all
  eight pilot IDs. The notebook fits balanced PCA; the benchmark fits PCA on all
  retained cells separately per line. These representations differ.
- The [synthetic table](../topoperturb_benchmark/outputs/synthetic_detection_table.csv)
  reports raw-H1 rejection on 40/40 scaling and 27/40 anisotropy replicates;
  normalized H1 rejects on 10/40 and 30/40. On `ring_k562`, raw/normalized/diffusion
  H1 reject on 1/40, 4/40 and 27/40. These are **diagram-difference rejection
  rates**, not direct loop-identification accuracy.
- The [real table](../topoperturb_benchmark/outputs/real_detection_table.csv) reports
  diffusion-H1 primary-draw BH q=0.04 for K562 RPL21 and q=0.02 for RPE1
  ZMAT2/CPSF3; rejection fractions are 13/15, 13/15 and 15/15. Control comparisons
  reject on 2/15 K562 and 0/15 RPE1 draws. These fractions describe resampling
  stability, not independent biological replication.
- **12 checks passed; two expected failures** expose boundary bugs. All benchmark
  table aggregates/BH values agree with the saved draws. Five selected comparisons
  reproduced all p-values and observed statistics at original permutation/surrogate
  counts ([tests](../results/audit/tests.txt), [replays](../results/audit/replay.json)).
  Matrix-arithmetic warnings occurred despite finite, matching outputs; they are recorded.
  Both benchmark figures regenerated pixel-for-pixel.
  Earlier-phase summaries can be checked arithmetically, but their original
  preprocessing and PH computations cannot be reconstructed from the supplied files.

## 3. Issues found

1. **The null hypothesis is not “same topology.”** Pooled label permutations test
   equality of distributions. Geometry alternatives violate that null. Dividing
   diagrams by mean pairwise distance removes scalar dilation of a fixed cloud,
   but does not make the permutation test valid for “same shape up to scale.”
   The 25% scaling rejection illustrates the distinction. Low diffusion rejection
   on one anisotropy model does not prove covariance invariance or establish
   real effects “beyond covariance.”
2. **Synthetic truth is overstated.** Gaussian mixtures and rings with Gaussian
   noise in every dimension have full support, not disconnected support or a
   literal hole. They model density structure/latent rings. `ring_k562` is an
   exact ellipse in two coordinates with noise elsewhere. Covariances match in
   population expectation, not exactly in sampled clouds. PH distance alone does
   not identify which loop changed. Figure “known truth” annotations need revision.
3. **Statistical scope is exploratory.** BH is across genes within each method
   and cell line, not across ten methods or all exploratory choices. Only 199
   permutations give minimum p=0.005; the K562 RPL21 q=0.04 uses that floor.
   Reused cells/shared controls limit replication claims. Phase 1 binomial win
   tests over repeated draws do not establish population-level replication.
   RPE1's “positive control” was selected for the largest observed centroid shift
   on the same data, not independently validated topology. Gaussian-surrogate
   p-values are plug-in comparisons; failure to reject does not prove equivalence.
4. **Reproducibility gaps and bugs.** No original environment, data revisions,
   cell IDs, PCA fit or missing phase scripts are recorded. The pilot notebook
   omits `gene_symbol`, breaking the subsequent loader if its output replaces the
   saved shortlist; saved null/summary outputs also exceed its implementation.
   `prep_real.py` uses a machine-specific cache path and does not validate/filter
   cached inputs. kNN fails for small clouds; normalization lacks zero-scale
   handling. Neither edge case has been shown to affect the saved 150-cell runs.
5. **Reports overclaim.** Dispersion is not significant for POLRMT/GFM1 in Phase 2;
   a lower participation ratio does not prove that anisotropy explains a PH effect.
   No guide/batch confounding check or biological loop validation is possible from
   saved inputs. PCA includes all selected groups, so RPE1 is a second context,
   not a held-out pipeline validation. Expression preprocessing is asserted in
   notebooks but could not be verified against the unavailable source matrices.

## 4. Scientific contribution

A focused empirical comparison shows that PH diagram differences can respond
strongly to geometry, while sensitivity to specified noisy-ring alternatives
depends on the metric. Diffusion PH gives exploratory signals in selected real
knockdowns worth investigating. Geometry sensitivity and spectral PH are prior
work; the contribution is their evaluation in this perturbation-comparison setup,
not a new PH method or a proven detector of biological topology changes. A
“first” claim is unsupported by the limited literature check.

## 5. Next steps

**Essential for the poster**

- [ ] Use the narrower contribution above; label real results exploratory and show
  denominators, uncertainty, per-method BH scope and both control rejection rates.
- [ ] Correct figure/caption truth labels; distinguish distribution testing from
  loop recovery. Replace “explained by covariance” with the actual tested evidence.
- [ ] Preserve verified replay records, inputs and environment; recover source
  revisions/preprocessing provenance. Recover missing phase scripts or label their
  results archival and exclude them from reproducibility claims.
- [ ] Repair the notebook-to-loader handoff before advertising an end-to-end run;
  state the primary method/analysis and disclose earlier exploratory selection.

**For a paper**

- [ ] Investigate nuisance-aware calibration, independent guide/batch replication,
  held-out selection and uncertainty beyond repeated draws of the same cells.
- [ ] Check PCA, kNN, diffusion-time and sample-size sensitivity; distinguish loops
  from mixtures/tails using interpretable features and biological metadata.
- [ ] Broaden simulations and the literature review before generality/novelty claims.
