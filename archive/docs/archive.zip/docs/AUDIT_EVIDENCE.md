# Audit evidence and limitations

31 October 2026. This is supporting detail for the short [research status](RESEARCH_STATUS.md).
No original scientific implementation or output was changed to improve agreement.

## Executed checks

There was no existing test suite or dependency manifest. The added
[`tests/test_research_checks.py`](../tests/test_research_checks.py) runs offline:

| Check | Evidence/result |
|---|---|
| PH on a unit square | Three finite H0 deaths at 1; one H1 bar from 1 to √2; empty-diagram Wasserstein handled correctly |
| Scale/translation | On a fixed random cloud, raw H1 scales by 1.3; normalized Euclidean and spectral summaries remain unchanged within numerical tolerance |
| Diffusion | Eigenvector construction matches direct eight-step random-walk distances; the omitted √graph-volume factor cancels under mean-distance normalization |
| Corrected resistance | Laplacian pseudoinverse correction matches the normalized-Laplacian spectral formula; this is squared Euclidean dissimilarity as in the cited paper, not a missing square-root bug |
| Baselines | Energy matches the unbiased within-group U-statistic form (it may be negative); covariance distance matches sample-covariance Frobenius norm |
| Permutations/BH | Ties use ≥, plus-one correction gives valid nonzero Monte Carlo ranks under exchangeability; BH agrees with SciPy |
| Synthetic construction | Finite 150×30 arrays, trace-preserving anisotropy with participation ratio 10, exact two-coordinate ellipse for `ring_k562` |
| Archived benchmark tables | All 120 synthetic rows including Wilson intervals/medians, and all 150 real summary rows including primary p/BH q, recomputed from 480/225 saved comparisons; unique complete replicate indices and p-value grids verified |
| Input checks | PCA arrays finite; all retained label counts match pilot inventories; K562 control spectrum agrees with metadata |
| Boundary probes | Two strict expected failures: kNN cannot handle n≤15; collapsed clouds are not rejected with a clear zero-scale error |

[Test output](../results/audit/tests.txt): 12 passed, two expected failures.
[Five replays](../results/audit/replay.json) reproduce all ten p-values and seven
observed statistics (tolerance rtol=1e-5, atol=1e-7): synthetic null/scaling/ring_k562
replicate 0, K562 RPL21 and RPE1 CPSF3 draw 0. All retain 199 permutations and
99 Gaussian surrogate pairs. Seeds are `[42, condition_index, replicate]` and
`[42, 77, group_index, draw]`. The script records warning counts and versions;
the [initial raw warning log](../results/audit/replay_initial.log.gz) is compressed.
No full benchmark rerun or new inferential experiment was performed.

The macOS/NumPy runtime reports invalid/overflow/divide-by-zero warnings in matrix
multiplication even with finite outputs. A [20-case check](../results/audit/matmul_check.json)
compares multiplication with explicit `einsum`; agreement and replay agreement
are reassuring, but the warning's underlying platform cause was not resolved.
Warnings were recorded, not treated as evidence that biological results are valid.
The deliberately tied surrogate test also exposes undefined z-scores when null
standard deviation is zero; its p-values remain one.

Additional executed arithmetic checks: all 64 Phase 1 ratio/win-rate entries
match `interpretation_repeats.csv`; `scale_test_summary.csv` p-values match
one-sided Binomial(30, 0.5) tails, with matching BH. Phase 1 H1 p-values match
`(n_ge+1)/2001`; all 66 Phase 2 PH p-values match stored counters/permutation
counts. Phase 2 conventional q-values match BH by measure. These checks cannot
validate the absent phase implementations or the assumptions behind their tests.

## Pipeline and scientific interpretation

[`prep_real.py`](../topoperturb_benchmark/prep_real.py) excludes `excluded` on TSV
loading and retains exact `non-targeting` controls. It performs no normalization,
log transform or feature scaling before randomized PCA (`random_state=42`). K562
uses all controls plus eight targets; RPE1 selects four shared targets and the
largest eligible full-expression centroid shift, then fits its own PCA. Controls
dominate the fit by cell count. The notebook instead fits PCA to 150 cells per
group. Missing expression data/loadings prevent tracing the stored coordinates
back to raw data or checking target-gene omission, QC and normalization claims.

[`real_battery.py`](../topoperturb_benchmark/real_battery.py) samples without
replacement within a draw; control-null comparisons split 300 distinct controls.
Draws share cells across repetitions. RPL21 has only 200 available K562 cells;
RPE1 CPSF3 has 173 and the selected positive control 168. These are stability
checks on fixed datasets, not independent experiments. A label-independent PCA
fit on the fixed selected pool is not automatically permutation leakage; however,
selection, shared representation and repeated reuse prevent a held-out-validation
claim. Without guide/batch metadata, biological exchangeability is unverified.

[`topo_battery.py`](../topoperturb_benchmark/topo_battery.py) computes Vietoris–Rips
PH over F₂ through H1, drops the infinite H0 bar, and compares diagrams using
Persim's sum-of-Euclidean-matching-cost Wasserstein convention. Scaling the
diagram is equivalent to scaling the filtration. Spectral graphs are built
separately for every cloud and permutation; unweighted symmetric kNN starts at
15 and increases by 5 until connected. Thus k is adaptive, not always 15, and
forcing connectivity can obscure disconnected structure. Mean normalization
does not align all group-specific graph properties.

Permutation statistics are rebuilt after each label shuffle. This is appropriate
for equality of distributions if cells are exchangeable, but not a calibrated
test of topology modulo geometry. The synthetic translation/scale transformations
preserve topology, yet their pooled nulls mix different distributions. Calling
all geometry rejections “false positives” is incorrect for energy/covariance tests
and not justified for topology inference without a defined nuisance-aware null.

Gaussian-surrogate samples use separately estimated means/covariances. Their
plus-one tail ranks are not an exact permutation test: parameter estimation is
not recalibrated. Heavy-tail rejection and K562 control H0 rejection (5/15) caution
against treating this as a topology-specific filter. Non-rejection does not show
that covariance explains everything. The reported Phase 2 surrogate comparisons
have minimum q≈0.0903, not demonstrated equivalence.

[`synth_bench.py`](../topoperturb_benchmark/synth_bench.py) correctly rescales t₅
noise to match covariance in expectation and preserves total variance when
sharpening eigenvalues. Rings with ambient Gaussian noise have full support;
the bimodal model also has full support and may have unequal sampled cluster
counts. Their intended truth is latent/density structure. The partial-knockdown
mixture intentionally changes mean and covariance. Plane-variance percentages
include noise variance in the first two coordinates, not just ring signal.
No direct loop matching/ground-truth feature recovery score is implemented.

## Provenance, reports and figures

- Both notebooks have no stored executions/outputs. The audit notebook leaves
  file and label configuration empty, and its count-column schema differs from
  the saved combined inventory. The pilot's IDs are count-stratified; reports
  describing functional-pair selection do not match that implementation. Gene
  symbols were added outside the supplied notebook; their annotation provenance
  is missing. The saved pilot control-null file has no generator in the notebook.
- `prep_real.py` silently prefers an absolute `/private/tmp/claude-501/...` cache,
  and cache loading ignores the requested label filter. Neither cache exists here.
  TSV header order, finite values and labels are insufficiently validated in that
  loader. No source download or raw-data PCA rerun was attempted in this audit.
  Mirror pages could not be read through web access, so their current schema and
  normalization remain unverified. Save revisions/hashes before future downloads.
- All 17 PNGs were visually inspected; all three Mapper HTML graph payloads were
  inspected (16/21/23 nodes) but not interactively validated. HTML views require
  external JavaScript CDNs. Two figure generators were rerun in a temporary copy
  and reproduced the original images pixel-for-pixel
  ([comparison](../results/audit/figure_checks.json)); prior-phase figures have no
  generating code. The benchmark heatmap's numbers
  agree with the saved table, but its “known truth / should stay ~5” annotations
  overstate what is tested. Concept figures show density patterns, not proofs.
- Historical `synth.log` has 11 conditions and predates `partial_kd`; the current
  CSVs have all 12. Plot titles hard-code 40/15 even if drivers use other counts.
  Drivers parse `sys.argv` at import and named-condition reruns require existing
  complete outputs. These are maintenance limitations, not changes to the method.
- Phase 1's robustness grid reports ratios/detection fractions versus a control
  null, not BH significance for every setting. “Significant in all 12 settings”
  is therefore stronger than that artifact supports. Phase 2's dispersion q is
  0.390/0.852 for POLRMT/GFM1, contradicting “spread found all eight.”
- No exhaustive literature review, biological feature validation, differential
  expression analysis, batch/guide adjustment or independent replication was
  verified. Do not interpret long bars alone as biological loops, nonsignificance
  as equality, or CRISPRi knockdown as complete gene inactivation.

## Sources checked

The corrected-resistance and diffusion formulas agree with Equations 1–4 and
Appendix F of [Damrich, Berens & Kobak (NeurIPS 2024)](https://proceedings.neurips.cc/paper_files/paper/2024/file/4a32a646254d2e37fc74a38d65796552-Paper-Conference.pdf).
That work already studies spectral PH on noisy high-dimensional and single-cell
data. [Turkeš, Montúfar & Otter (NeurIPS 2022)](https://papers.neurips.cc/paper_files/paper/2022/hash/e637029c42aa593850eeebf46616444d-Abstract-Conference.html)
already examines PH's geometric and topological sensitivity. The
[CausalBench publication](https://pmc.ncbi.nlm.nih.gov/articles/PMC11897147/)
supports the dataset/control totals and describes preprocessed CRISPRi data;
this does not authenticate the particular TSV mirrors. These limited checks
support attribution, not an exhaustive novelty determination.

## Repository changes

Moved reports into `docs/archive/`, notebooks into `experiments/`, and combined
count inventories into `results/data_audit/`. Left original scripts and dependent
output directories together. Added documentation, ignored local caches/reproductions,
audit requirements, checks and evidence. Replaced the benchmark README with a
qualified guide while preserving its original text in `docs/archive/benchmark_README.md`.
Git history was not rewritten; the original root README remains in history.
The [preservation manifest](../results/audit/preservation.json) records old/new
locations and SHA-256 hashes for original artifacts.
