# TopoPerturb benchmark

Compare 12 synthetic conditions (40 replicates each) and 15 real-data groups
(15 draws each), using 150 cells per cloud and 30 dimensions. The ten methods are
energy, covariance difference, raw H1, scale-normalized H0/H1, corrected
effective-resistance H1, diffusion H1, and three Gaussian-surrogate comparisons.

See the [root README](../README.md) for installation and commands that preserve
the archived results, and [RESEARCH_STATUS](../docs/RESEARCH_STATUS.md) for what
the evidence supports. The [original benchmark narrative](../docs/archive/benchmark_README.md)
is retained as a historical record.

| Script | Role |
|---|---|
| `prep_real.py` | Load expression matrices; fit a separate 30-PC representation per cell line |
| `topo_battery.py` | Compute all ten tests, including 199 label permutations and 99 surrogate pairs |
| `synth_bench.py` | Generate synthetic comparisons using the saved control covariance spectrum |
| `real_battery.py` | Sample cells, run tests, and apply BH across genes per method and cell line |
| `make_figures.py` | Plot both saved detection tables |
| `concept_figure.py` | Draw a conceptual geometry/ring/mixture illustration |

The archived results show sensitivity to scale and anisotropy for Euclidean PH,
and greater sensitivity to the selected ring alternatives for diffusion PH.
Real diffusion-H1 primary-draw q-values are 0.04 for K562 RPL21 and 0.02 for
RPE1 ZMAT2/CPSF3. These are exploratory distribution-comparison results, not
proof of loops or changes beyond covariance. Repeated real draws reuse cells.

All original scripts and output files are preserved. In particular, the figure
annotations and `true_topology_change` column have not been silently rewritten:
noisy rings and Gaussian mixtures need a more precise interpretation before
submission. The synthetic log predates the added partial-knockdown condition.
