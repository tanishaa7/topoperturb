# TopoPerturb

TopoPerturb investigates how persistent homology (PH) responds to changes in
single-cell CRISPR perturbation data from CausalBench K562 and RPE1. The current
benchmark compares geometric transformations, synthetic rings/mixtures, and
selected real knockdowns. It measures differences between persistence diagrams;
it has **not established biological topology changes**.

Start with [the research audit](docs/RESEARCH_STATUS.md). Historical reports contain
stronger claims and should not be used as submission text without those caveats.

## Directory guide

| Location | Contents |
|---|---|
| `topoperturb_benchmark/` | Six original scripts: PCA preparation, shared test battery, synthetic/real runs, two figure generators |
| `topoperturb_benchmark/outputs/` | Saved 30-PC clouds, metadata, 480 synthetic comparisons, 225 real draws, summary tables, logs and figures |
| `experiments/` | Original dataset-audit and PCA/Mapper notebooks; small benchmark replay script |
| `topoperturb_pilot_outputs/` | Shortlist, cell counts, descriptive PCA statistics, plot and three Mapper HTML files |
| `topoperturb_ph_outputs/` | Initial Euclidean PH, nulls, target-gene omission checks and diagrams |
| `topoperturb_phase1_outputs/` | Permutation, sampling/PCA robustness, scaling and cycle summaries |
| `topoperturb_phase2_outputs/` | Normalized/spectral PH, conventional baselines, surrogates and RPE1 summaries |
| `results/data_audit/` | Original combined cell-count and shared-target inventories |
| `results/audit/`, `tests/` | Audit evidence and small offline verification checks |
| `docs/` | Current status and detailed evidence; `archive/` preserves original reports and benchmark narrative |

Existing experiment/output directories stay together because scripts refer to
them directly. Raw expression matrices and the PH/Phase 1–2 generating scripts
are absent. No original data, results, figures or scientific code were discarded.

## Environment and quick verification

From the repository root, use Python 3.9 (the audit environment) and an isolated
environment. The pinned requirements describe the audit, not the unknown original
run environment.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-audit.txt
python -m pytest -q tests
python experiments/replay_benchmark_checks.py
```

Tests check formulas, invariance, saved table arithmetic and input consistency.
Two expected failures document small/degenerate-cloud edge cases. The replay
executes three synthetic replicate-0 comparisons and two real primary draws at
the original 150 cells, 30 dimensions, 199 permutations and 99 surrogate pairs;
it writes `results/audit/replay.json`. It is a spot check, not the full study.

## Reproduce the main benchmark from saved PCA clouds

The original drivers write into their own `outputs/` directory. Run a separate
copy to preserve the archived results (choose a fresh directory for each run):

```bash
mkdir -p results/reproduced
cp -R topoperturb_benchmark results/reproduced/benchmark
python results/reproduced/benchmark/synth_bench.py 40
python results/reproduced/benchmark/real_battery.py 15
python results/reproduced/benchmark/make_figures.py
python results/reproduced/benchmark/concept_figure.py
```

This runs 12 synthetic conditions and 15 real groups through 10 methods, using
eight worker processes. Historical logs report about 31 minutes for an earlier
11-condition synthetic run and 19 minutes for the real run; local runtime varies.
The figure scripts alone can regenerate plots from the copied tables. Their
original annotations include overstated topology claims; see the audit before
using them on a poster. Named synthetic reruns (for example `synth_bench.py 40 null`)
merge into an existing replicate file and require all other conditions to exist.

## Rebuild upstream inputs (not verified end to end)

`prep_real.py` reads the original pilot shortlist relative to its parent directory,
then looks for old machine-specific caches and otherwise downloads Hugging Face
TSVs. In an isolated benchmark copy, its expected sibling shortlist can be provided
with:

```bash
mkdir -p results/reproduced/topoperturb_pilot_outputs
cp topoperturb_pilot_outputs/pilot_perturbations.csv results/reproduced/topoperturb_pilot_outputs/
python results/reproduced/benchmark/prep_real.py
```

This replaces the copied PCA clouds and metadata. It requires `huggingface_hub`
(`python -m pip install huggingface_hub`) and working access to both mirrors. It
does not add a log transform or normalization. Original file revisions, expression
preprocessing, PCA loadings, cell IDs and original dependency versions were not
saved; exact upstream reproduction cannot currently be promised.

The notebooks are unexecuted templates. Copy them to a fresh working directory
before running their install/configuration cells: paths are relative to the kernel
working directory. The audit notebook needs file/label choices filled in. The pilot
notebook reproduces the eight IDs from saved counts, but omits the `gene_symbol`
column expected by `prep_real.py` and lacks some saved summary/null outputs. Do not
replace the archived shortlist with its output until that handoff is repaired.

The missing PH/Phase 1–2 scripts prevent complete reproduction of those stages.
Their saved results remain available for inspection, separately from the executed
benchmark checks.
