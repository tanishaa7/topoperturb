# Historical TopoPerturb files

Original paths are retained inside this archive.

- topoperturb_pilot_outputs/: exploratory PCA, Mapper, duplicated counts and summaries.
- topoperturb_ph_outputs/: initial PH results and diagrams.
- topoperturb_phase1_outputs/: robustness, scale and interpretation results.
- topoperturb_phase2_outputs/: baselines, surrogates and earlier RPE1 checks.
- experiments/: original exploratory notebooks.
- docs/archive/: original reports and research plan.
- docs/AUDIT_EVIDENCE.md, results/audit/: full first-audit evidence.
- topoperturb_benchmark/: retired conceptual figure/logs and original versions of reorganized scripts.
- README.md, docs/RESEARCH_STATUS.md, tests/: documentation/checks before consolidation.
- MANIFEST.json: previous locations, current working locations, hashes, and archived copies.

Main benchmark data and results are kept outside this archive in data/ and results/.
Historical markdown refers to the old layout. Extract to a separate directory when needed.

## Recovered on 1 November 2026

Exact incoming scripts are preserved under recovered_sources/, with their manifest. Active unique earlier analyses now live in src/earlier/ and use data/expression_k562.npz and expression_rpe1.npz. The recovered expression arrays are preserved value-for-value in those compressed inputs, with hashes in data/provenance.json. Duplicate incoming directories and ZIP containers were removed only after verification. Earlier archived audit notes describe the repository before recovery; docs/RESEARCH_STATUS.md is the current status.
